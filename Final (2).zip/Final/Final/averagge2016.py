import os
import csv
data = open('filteredData.csv','r')
# Create Dictionaries to store location values
# Snow_Fall is the number of inches for that location
# Number_Days is the number of days that there is Snowfall data for
Snow_Fall = {}
Number_Days = {}

# Create CSV reader
csv1 = csv.DictReader(data,delimiter=',')
# read each row of the CSV file and process it
for row in csv1:
    # Check the date column and see if it is in 2016
    if "2016" in row["DATE"]:
        # Split the date into Month, Day and Year
        Month, Day, Year = row["DATE"].split("/")
        # Check to see if the value in the snow column is null/none if so then skip processing that row
        if (row["SNOW"] is None) or (row["SNOW"] == ""):
            pass
        else:
            # Check to see if the location has been added to the dict if it has then add the data to itself
            # If it has not then just assign the data to the location.
            # Concat the Location and Month together to get a unique location per month
           # print (" The location is ==> " + row["NAME"] + " <<++>> The Month is " + str(Month))
            name_date = row["NAME"] + "_" + str(Month)
            if name_date in Snow_Fall:
                Snow_Fall[name_date] = Snow_Fall[name_date] + float(row["SNOW"])
                Number_Days[name_date] = Number_Days[name_date] + 1
            else:
                Snow_Fall[name_date] = float(row["SNOW"])
                Number_Days[name_date] = 1

# For each location we want to print the data for that location
for location in Snow_Fall:
   # split the location into Name and month
   location_name, location_date = location.split("_")
   #print ("The number of inches for location " + location_name + " in the Month of " + location_date + " is " + str(Snow_Fall[location]))            
   #print ("The number of days of snowfall for location " + " in the Month of " + location_date+ location_name + " is " + str(Number_Days[location]))
   #print ("The average Number of Inches for location " + location_name + " in the Month of " + location_date + " is " + str(Snow_Fall[location] / Number_Days[location]))

# Check if file exists then remove it if it does   
if (os.path.isfile('average2016.csv')):
   os.remove('average2016.csv')
# Open file   
data2 = open('average2016.csv','w')
# Write File headers
data2.write("Location,Month_2016,AverageSnowFall\n")
# Write contents of the file
for location in Snow_Fall:
    # SPlit the location into name and month
    location_name, location_date = location.split("_")
    data2.write('"' + location_name + '",' + location_date + "," + str(Snow_Fall[location] / Number_Days[location]) + "\n")
print("completed")

# Close the open files
data2.close()
data.close()

