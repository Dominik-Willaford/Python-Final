import pandas as pd
df1 = pd.read_csv('filteredData.csv')

df1 = df1.drop(df1[df1.AWND < 18.79].index)
df1 = df1.drop(['STATION','NAME','DATE','SNOW'],axis=1)

df2 = df1.set_index("AWND")
df2.to_csv('top10AWND.csv')
