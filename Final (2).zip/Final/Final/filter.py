import pandas as pd
df1 = pd.read_csv('Data.csv')

df1 = df1.drop(['AWND_ATTRIBUTES','DAPR','DAPR_ATTRIBUTES','MDPR','MDPR_ATTRIBUTES',
                  'PGTM','PGTM_ATTRIBUTES','PRCP','PRCP_ATTRIBUTES','SNOW_ATTRIBUTES',
                  'SNWD','SNWD_ATTRIBUTES','TAVG','TAVG_ATTRIBUTES','TMAX','TMAX_ATTRIBUTES',
                  'TMIN','TMIN_ATTRIBUTES','TOBS','TOBS_ATTRIBUTES','WDF2','WDF2_ATTRIBUTES',
                  'WDF5','WDF5_ATTRIBUTES','WESD','WESD_ATTRIBUTES','WESF','WESF_ATTRIBUTES',
                  'WSF2','WSF2_ATTRIBUTES','WSF5','WSF5_ATTRIBUTES'],axis =1)
df2 = df1.set_index("STATION")
df2.to_csv('filteredData.csv')
