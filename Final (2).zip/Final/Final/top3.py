import pandas as pd
df1 = pd.read_csv('average2016.csv')

df1 = df1.drop(df1[df1.AverageSnowFall < 2.39].index)
df1 = df1.drop(['Location'],axis=1)


df2 = df1.set_index("Month_2016")
df2.to_csv('top3.csv')




